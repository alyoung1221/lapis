import { Concept } from "./about.concept";


export const CONCEPT: Concept[] = [
    {id: 34, name: "Lapis"},
    {id: 56, name: 'Root'},
    {id: 67, name:'Arrow'},
    {id: 25, name: 'Tree'},
    {id: 67, name: 'Frobby'}
]
}