import { Component, OnInit } from "@angular/core";
import { ConnectionOptions } from "tls";

@Component({
  selector: "app-about",
  templateUrl: "./about.component.html",
  styleUrls: ["./about.component.css"]
})
export class AboutComponent implements OnInit {
  constructor() {}
  concept = CONCEPT;
  selectedConcept: ConnectionOptions;
  ngOnInit() {}
  onSelect(concept: Concept): void {
    this.selectedConcept = concept;
  }
}
